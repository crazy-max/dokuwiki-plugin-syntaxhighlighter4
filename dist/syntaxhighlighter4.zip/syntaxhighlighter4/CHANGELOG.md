# Changelog

## 2016/06/19

* Initial version based on SyntaxHighlighter 4.0.1 (Sun, 19 Jun 2016 01:01:23 GMT)

# Changelog

## 2016/10/24

* onoff values are `true` or `false` (Issue #3)
* Apply StyleCI

## 2016/06/19

* Initial version based on SyntaxHighlighter 4.0.1 (Sun, 19 Jun 2016 01:01:23 GMT)
